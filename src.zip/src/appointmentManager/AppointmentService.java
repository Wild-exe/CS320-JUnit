package appointmentManager;

import java.time.LocalDate;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class AppointmentService {
	public Map<String, Appointment> appointmentList = new HashMap<String, Appointment>();
	
	public String addAppointment(String appointmentDescription, int year, int month, int day) {		// Creates Appointment.				
		String lastKey = confirmID();																// Assigns lastKey with confirmID method
		Appointment appointment = new Appointment(lastKey, appointmentDescription, LocalDate.of(year, month, day));	// Create appointment with parameters including date.
		appointmentList.put(lastKey, appointment);													// Assigns the key-value pair to the appointmentList.
        return lastKey;
    }
	private static String generateID () {							// Creates AppointmentID
	    String initialID = UUID.randomUUID().toString();			// Assign a random UUID to initial ID as a string.
	    return initialID.substring(initialID.length() - 10);		// Returns the last 10 characters of the initialID.
	}
	private String confirmID() {									// Verifies the generated ID is not already used.
		String tempID;
    	do {
        	tempID = generateID();									// Do assign the returned ID value to tempID,
        } while (appointmentList.containsKey(tempID));				// while AppointmentList contains the key AppointmentID value.
      return tempID;												// Returns the ID after exiting the loop if the ID is unique.
    } 
	public void deleteAppointment(String appointmentID) {			// Method for deleting the Appointment.
		if (appointmentList.containsKey(appointmentID)) {	
			appointmentList.remove(appointmentID);						// Removes the Appointment object value based on the key AppointmentID.
		} else {
			throw new IllegalArgumentException("Appointment ID does not exist"); // If the appointmentID does not exist throw exception.
		}		
	}

	public String getAppointmentDescription(String appointmentID) { return appointmentList.get(appointmentID).getAppointmentDescription(); }
	public LocalDate getAppointmentDate(String appointmentID) {return appointmentList.get(appointmentID).getAppointmentDate(); }
}
