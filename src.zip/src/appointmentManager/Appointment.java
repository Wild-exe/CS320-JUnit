package appointmentManager;

import java.time.LocalDate;

public class Appointment { 
	private String appointmentID;
	private String appointmentDescription;
	private LocalDate appointmentDate;
	private static final byte ID_LENGTH = 10;	
	private static final byte DESCRIPTION_LENGTH = 50;
	
	public Appointment(String appointmentID, String appointmentDescription, LocalDate appointmentDate) { // Constructor
        this.appointmentID = setAppointmentID(appointmentID);											// Calls validating set methods to assign parameter
        this.appointmentDescription = setAppointmentDescription(appointmentDescription);
        this.appointmentDate = setAppointmentDate(appointmentDate);
	}

	
	public String setAppointmentID(String appointmentID) {
		if (appointmentID == null) {														// If there is not a value,
			throw new IllegalArgumentException("Appointment ID cannot be empty.");			// throw exception
		} else if (appointmentID.length() > ID_LENGTH) {									// If the length is greater than the allowed length,
			throw new IllegalArgumentException("Appointment ID cannot exceed " + ID_LENGTH + " characters.");  // throw exception.
		} else {
			return appointmentID;															// Else assign to to the contact
		}	
	}
	public String setAppointmentDescription(String appointmentDescription) {
		if (appointmentDescription == null) {												
			throw new IllegalArgumentException("Appointment description cannot be empty.");	
		} else if (appointmentDescription.length() > DESCRIPTION_LENGTH) {					
			throw new IllegalArgumentException("Appointment description cannot exceed " + DESCRIPTION_LENGTH + " characters.");  
		} else {
			return appointmentDescription;							
		}
	}
	public LocalDate setAppointmentDate(LocalDate appointmentDate) {						
		if (appointmentDate == null) {													
			throw new IllegalArgumentException("Appointment date cannot be empty");
		} else if (appointmentDate.isBefore(LocalDate.now())) {								// If the appointment date is before today's date,
			throw new IllegalArgumentException("Appointment date cannot be before today's date.");	// throw exception.
		} else {
			return appointmentDate;
		}
	}
	public final String getAppointmentID() { return appointmentID; }
	public final String getAppointmentDescription() { return appointmentDescription; }
	public final LocalDate getAppointmentDate() { return appointmentDate; }
}
