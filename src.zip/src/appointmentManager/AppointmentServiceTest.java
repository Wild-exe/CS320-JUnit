package appointmentManager;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertThrows;
import static org.junit.Assert.assertTrue;

import java.time.LocalDate;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

public class AppointmentServiceTest {
private AppointmentService appointmentService;
private String testKey;
    @BeforeEach																	// Before each test.
    public void setup() {
        System.out.println("Instantiating Contact List");
        appointmentService = new AppointmentService();							// Create class Object
        int year = LocalDate.now().plusDays(1).getYear();						// Assigns tomorrow's year, month and day.
        int month = LocalDate.now().plusDays(1).getMonthValue();
        int day = LocalDate.now().plusDays(1).getDayOfMonth();
        testKey = appointmentService.addAppointment("This Description", year, month, day );	// Call addContact method with contact variables.
    }

    @Test
    @DisplayName("Appointment Added")
	public void testAddAppointment() {
	    assertFalse(appointmentService.appointmentList.keySet().isEmpty());  	// Passes if the HashMap is not empty.
	    assertEquals(1, appointmentService.appointmentList.keySet().size());	// Passes if there is one appointment in HashMap.
	    assertFalse(appointmentService.appointmentList.containsKey(testKey) && appointmentService.appointmentList.get(testKey) == null); // Passes if HashMap key value pair is not null.
	    assertEquals("This Description", appointmentService.getAppointmentDescription(testKey));	// Passes if appointment description is This Description.
	    assertEquals(LocalDate.now().plusDays(1), appointmentService.getAppointmentDate(testKey));	// Passes if appointment date is tomorrow's date.
    }  
    @Test
    @DisplayName("Delete Last Appointment")
    public void testDeleteContact() {
    	assertThrows(IllegalArgumentException.class, () -> {					// Passes if the appointmentList does not contain the key, "Not a key"
    		appointmentService.deleteAppointment("Not a Key");					// Passes if appointmentID is incorrect.
        });
    	appointmentService.deleteAppointment(testKey);   						// Deletes the appointment date.
    	assertTrue(appointmentService.appointmentList.keySet().isEmpty());		// Passes if appointmentList is empty. 
    }
}
