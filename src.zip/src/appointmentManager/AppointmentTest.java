package appointmentManager;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertThrows;
import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.time.LocalDate;

public class AppointmentTest {
private Appointment appointment;
    
    @BeforeEach
    public void setup() {
        System.out.println("Instantiating Appointment");	
        appointment = new Appointment("ValidID", "ValidDescription", LocalDate.now().plusDays(2));	//Creates the class object for each test.
    }
  
	@Test
	@DisplayName("Testing Appointment")
	public void testAppointment() {
		assertEquals("ValidID", appointment.getAppointmentID());									// Passes if the variables was assigned properly
		assertEquals("ValidDescription", appointment.getAppointmentDescription());
		assertEquals(LocalDate.now().plusDays(2), appointment.getAppointmentDate());
	}
    @Test
    @DisplayName("Validating AppointmentID for null and length.")
	public void testValidateAppointmentID() {
    	assertThrows(IllegalArgumentException.class, () -> {  										// Passes if exception is thrown.
            appointment.setAppointmentID(null);														// Testing for null.
        });
    	assertThrows(IllegalArgumentException.class, () -> {
            appointment.setAppointmentID("A".repeat(11));											// Testing with invalid string length.
        });
    	assertDoesNotThrow(() -> {																	// Passes if exception is not thrown.
    		appointment.setAppointmentID("Valid");													// Testing with valid string.
    	});
    }
    @Test
    @DisplayName("Validating Appointment Description for null and length.")
	public void testValidateAppointmentDescription() {
    	Throwable exception = assertThrows(
    	        IllegalArgumentException.class, () -> {
    	        	appointment.setAppointmentDescription(null);
		});
    	assertEquals("Appointment description cannot be empty.", exception.getMessage()); 
    	assertThrows(IllegalArgumentException.class, () -> {
    		appointment.setAppointmentDescription("A".repeat(51));
        });
    	assertDoesNotThrow(() -> {
    		appointment.setAppointmentDescription("Valid");
    	});
    }
    @Test
    @DisplayName("Validating Appointment date for null and date.")
	public void testValidateAppointmentDate() {
    	assertThrows(IllegalArgumentException.class, () -> { 			
    	        	appointment.setAppointmentDate(null);
		});
    	Throwable exception = assertThrows(														// Assigns the illegal argument exception if thrown
    	        IllegalArgumentException.class, () -> {
    		appointment.setAppointmentDate(LocalDate.now().minusDays(1));						// Passes if yesterday is before today.
        });
    	assertEquals("Appointment date cannot be before today's date.", exception.getMessage()); // Passes if the message string is the same.
    	assertDoesNotThrow(() -> {
    		appointment.setAppointmentDate(LocalDate.now().plusDays(2));						// Passes if the date is after today.
    	});
    }
}
