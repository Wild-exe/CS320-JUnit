package taskManager;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertThrows;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

public class TaskTest {
	private Task task;
    
    @BeforeEach
    public void setup() {
        System.out.println("Instantiating Task");
        task = new Task("ValidID", "ValidName", "ValidDescription");	//Creates the class object for each test.
    }
  
	@Test
	@DisplayName("Testing Task")
	public void testTask() {
		assertEquals("ValidID", task.getTaskID());						// Passes if the variables was assigned properly
		assertEquals("ValidName", task.getTaskName());
		assertEquals("ValidDescription", task.getTaskDescription());
	}
    @Test
    @DisplayName("Validating Task ID for null and length.")
	public void testValidateTaskID() {
    	assertThrows(IllegalArgumentException.class, () -> {  			// Passes if exception is thrown.
            task.setTaskID(null);										// Testing validateTaskID method for null.
        });
    	assertThrows(IllegalArgumentException.class, () -> {
            task.setTaskID("A".repeat(11));								// Testing validate method for string with a length of 11.
        });
    	assertDoesNotThrow(() -> {										// Passes if a valid taskID is provided.
    		task.setTaskID("Valid");
    	});
    }
    @Test
    @DisplayName("Validating Task Name for null and length.")
	public void testValidateTaskName() {
    	assertThrows(IllegalArgumentException.class, () -> {
            task.setTaskName(null);
        });
    	assertThrows(IllegalArgumentException.class, () -> {
    		task.setTaskName("A".repeat(21));
        });
    	assertDoesNotThrow(() -> {
    		task.setTaskName("Valid");
    	});
    }
    @Test
    @DisplayName("Validating Task Description for null and length.")
	public void testValidateTaskDescription() {
    	Throwable exception = assertThrows(
    	        IllegalArgumentException.class, () -> {
    		task.setTaskDescription(null);
		});
    	assertEquals("Task description cannot be empty.", exception.getMessage()); 
    	assertThrows(IllegalArgumentException.class, () -> {
    		task.setTaskDescription("A".repeat(51));
        });
    	assertDoesNotThrow(() -> {
    		task.setTaskDescription("Valid");
    	});
    }
}