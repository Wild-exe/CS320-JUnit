package taskManager;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class TaskService {
	public Map<String, Task> taskList = new HashMap<String, Task>(); 	// Task container for storing and searching.

	public String addTask(String taskName, String taskDescription) {	// Method for adding a task.
		String lastKey = confirmID();									// Store returned confirmID value to temporary string.
        Task task = new Task(lastKey, taskName, taskDescription);		// Create new Task object.
        taskList.put(lastKey, task);									// After validating values, stores the task object in taskList.
        return lastKey;
    }
	private static String generateID () {								// Creates taskID
	    String initialID = UUID.randomUUID().toString();				// Assign a random UUID to initial ID as a string.
	    return initialID.substring(initialID.length() - 10);			// Returns the last 10 characters of the initialID.
	}
	private String confirmID() {										// Verifies the generated ID is not already used.
		String tempID;
    	do {
        	tempID = generateID();										// Do assign the returned ID value to tempID,
        } while (taskList.containsKey(tempID));							// while taskList contains the key taskID value.
      return tempID;													// Returns the ID after exiting the loop if the ID is unique.
    } 
	public void deleteTask(String taskID) {								// Method for deleting the key value pair for the task.
		if (taskList.containsKey(taskID)) {						  		// If the taskID exists,
			taskList.remove(taskID);									// Removes the Task object value based on the taskID key.
		} else {
			throw new IllegalArgumentException("Task ID does not exist"); 	// If the taskID does not exist throw exception.
       }  
	}
        
    public void updateTaskName(String taskID, String taskName) {		// Updates the task name of the taskID Task.
    	if (taskList.containsKey(taskID)) {						  		// If the taskID exists,
    		taskList.get(taskID).newTaskName(taskName);					// Return the task and call the validateTaskName method using the new task name.
        } else {
          throw new IllegalArgumentException("Task ID does not exist"); 	// If the taskID does not exist throw exception.
        }   		
    }
    public void updateTaskDescription(String taskID, String taskDescription) {  // Updates the task description of the taskID Task.
    	if (taskList.containsKey(taskID)) {										
    		taskList.get(taskID).newTaskDescription(taskDescription);		
        } else {
          throw new IllegalArgumentException("Task ID does not exist");
        }   		
    }
	public String getTaskName(String taskID) { return taskList.get(taskID).getTaskName(); } // Getters for contact details
	public String getTaskDescription(String taskID) { return taskList.get(taskID).getTaskDescription(); }
}
