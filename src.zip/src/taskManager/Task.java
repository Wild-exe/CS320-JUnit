package taskManager;

public class Task {
	private String taskID;														// Required variables.
	private String taskName;
    private String taskDescription;
    private static final byte ID_LENGTH = 10;									// Length requirements
	private static final byte NAME_LENGTH = 20;
	private static final byte DESCRIPTION_LENGTH = 50;
	
	public Task(String taskID, String taskName, String taskDescription) {		// Constructor
        this.taskID = setTaskID(taskID);										// Calls validating set methods to assign parameter
        this.taskName= setTaskName(taskName);
        this.taskDescription= setTaskDescription(taskDescription);
	}
	
	public String setTaskID(String taskID) {									// Ensures the taskID before assigning.
		if (taskID == null) {													// If there is not a value,
			throw new IllegalArgumentException("Task ID cannot be empty.");		// throw exception
		} else if (taskID.length() > ID_LENGTH) {								// If the length is greater than the allowed length,
			throw new IllegalArgumentException("Task ID cannot exceed " + ID_LENGTH + " characters.");  // throw exception.
		} else {
			return taskID;												// Else assign the taskID to this task's taskID
		}
    }
	public String setTaskName(String taskName) {								// Ensures the task name before assigning.
		if (taskName == null) {													
			throw new IllegalArgumentException("Task name cannot be empty.");	
		} else if (taskName.length() > NAME_LENGTH) {							
			throw new IllegalArgumentException("Task name cannot exceed " + NAME_LENGTH + " characters.");
		} else {
			return taskName;											
		}
    }
	public String setTaskDescription(String taskDescription) {				// Ensures the task description before assigning.
		if (taskDescription == null) {											
			throw new IllegalArgumentException("Task description cannot be empty.");	
		} else if (taskDescription.length() > DESCRIPTION_LENGTH) {				
			throw new IllegalArgumentException("Task description cannot exceed " + DESCRIPTION_LENGTH + " characters.");
		} else {
			return taskDescription;								
		}
    }
	
	public void newTaskName(String taskName) {								// Update setter methods for testing updates in task service.
		this.taskName = setTaskName(taskName);
	}	
	public void newTaskDescription(String taskDescription) {
		this.taskDescription = setTaskDescription(taskDescription);
	}
	
	public final String getTaskID() { return taskID; }							// Getters for the class variables.
	public final String getTaskName() { return taskName; }
	public final String getTaskDescription() { return taskDescription; }	
}
