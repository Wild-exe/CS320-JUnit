package taskManager;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertThrows;
import static org.junit.Assert.assertTrue;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

public class TaskServiceTest {
	private TaskService taskService; 
    private String testKey;
	@BeforeEach																		// Before each test.
    public void setup() {
        System.out.println("Instantiating Contact List");
        taskService = new TaskService();											// Create class Object
        testKey = taskService.addTask("Task Name", "Description"); 					// Call addTask method with task parameters.
    }
	
    @Test
    @DisplayName("Task Added")
	public void testAddTask() {
	    assertFalse(taskService.taskList.keySet().isEmpty());  						// Passes test if the HashMap is not empty.
	    assertEquals(1, taskService.taskList.keySet().size());						// Passes test if there is one task in HashMap.
	    assertTrue(taskService.taskList.containsKey(testKey) && taskService.taskList.get(testKey) != null); // Passes if taskList contains key and taskList value is not null.
	    assertEquals("Task Name", taskService.getTaskName(testKey));				// Passes if task name is assigned.
	    assertEquals("Description", taskService.getTaskDescription(testKey));		// Passes if task description is assigned.
    }  
    @Test
    @DisplayName("Update Task Name")
    public void testUpdateTaskName() {
		taskService.updateTaskName(testKey, "New Name");							// Updates the value from Task Name to New Name.
		assertEquals("New Name", taskService.getTaskName(testKey));					// Passes test if the taskName returned is New Name.
		assertThrows(IllegalArgumentException.class, () -> {						// Passes if the taskList does not contain the key, "Not a key"
    		taskService.updateTaskName("Not a Key", "Task Name");
        });
    }
    @Test
    @DisplayName("Update Task Description")
    public void testUpdateTasKDescription() {
		taskService.updateTaskDescription(testKey, "New Description");				// Updates the value from Description to New Description.
		assertEquals("New Description", taskService.getTaskDescription(testKey));	// Passes test if the taskDescription returned is New Description.
    	assertThrows(IllegalArgumentException.class, () -> {
    		taskService.updateTaskDescription("Not a Key", "Task Description");
        });
    }
    @Test
    @DisplayName("Delete Task")
    public void testDeleteContact() {
    	assertThrows(IllegalArgumentException.class, () -> {
    		taskService.deleteTask("Not a Key");
        });
    	taskService.deleteTask(testKey);   											// Deletes the before each contact service key value pair.
    	assertTrue(taskService.taskList.keySet().isEmpty());						// Passes if taskList is empty. 
    }    
}


