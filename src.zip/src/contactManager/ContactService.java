package contactManager;

import java.util.Map;										// Used for the contact HashMap
import java.util.HashMap;									// Used to store the contacts searchable by contactID
import java.util.UUID;										// Used to generate Unique contactIDs
 
public class ContactService {
	public Map<String, Contact> contactList = new HashMap<String, Contact>(); 		// Contact container for storing and searching.
	
	public String addContact(String firstName, String lastName, String phoneNumber, String address) {		// Add contact method
		String lastKey = confirmID();								// Store returned confirmID value to temporary string.
        Contact contact = new Contact(lastKey, firstName, lastName, phoneNumber, address);	// Create contact 
        contactList.put(lastKey, contact);							// After validating values, stores the contact in contactList.
        return lastKey;
	}
	private static String generateID () {							// Creates contactID
	    String initialID = UUID.randomUUID().toString();			// Assign a random UUID to initial ID as a string.
	    return initialID.substring(initialID.length() - 10);		// Returns the last 10 characters of the initialID.
	}
	private String confirmID() {									// Verifies the generated ID is not already used.
		String tempID;
    	do {
        	tempID = generateID();									// Do assign the returned ID value to tempID,
        } while (contactList.containsKey(tempID));					// while contactList contains the key contactID value.
      return tempID;												// Returns the ID after exiting the loop if the ID is unique.
    } 
	public void deleteContact(String contactID) {					// Method for deleting the contact.
		if (contactList.containsKey(contactID)) {	
			contactList.remove(contactID);							// Removes the contact object value based on the key contactID.
		} else {
			throw new IllegalArgumentException("Contact ID does not exist"); // If the contactID does not exist throw exception.
		}
	}
        
    public void updateFirstName(String contactID, String firstName) {  // Updates the first name of the contactID contact.
    	if (contactList.containsKey(contactID)) {						// If the contactID exists
    		contactList.get(contactID).newFirstName(firstName);		// Return the contact and call the validateFirstName method using the new first name.
        } else {
          throw new IllegalArgumentException("Contact ID does not exist");
        }   		
    }
	
    public void updateLastName(String contactID, String lastName) {			// Updates Last Name
    	if (contactList.containsKey(contactID)) {
    		contactList.get(contactID).newLastName(lastName);
        } else {
          throw new IllegalArgumentException("Contact ID does not exist");
        }   		
    }
    public void updatePhoneNumber(String contactID, String phoneNumber) {	// Updates Phone Number
    	if (contactList.containsKey(contactID)) {
    		contactList.get(contactID).newPhoneNumber(phoneNumber);
        } else {
          throw new IllegalArgumentException("Contact ID does not exist");
        }   		
    }
    public void updateAddress(String contactID, String address) {			// Updates Address
    	if (contactList.containsKey(contactID)) {
    		contactList.get(contactID).newAddress(address);
        } else {
          throw new IllegalArgumentException("Contact ID does not exist");
        }   		
    }
	
	public String getContactFirstName(String contactID) { return contactList.get(contactID).getFirstName(); } // Getters for contact details
	public String getContactLastName(String contactID) { return contactList.get(contactID).getLastName(); }
	public String getContactPhoneNumber(String contactID) { return contactList.get(contactID).getPhoneNumber(); }
	public String getContactAddress(String contactID) { return contactList.get(contactID).getAddress(); }	
}
 
