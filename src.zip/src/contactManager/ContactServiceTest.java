package contactManager;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertThrows;
import static org.junit.Assert.assertTrue;

public class ContactServiceTest {
    private ContactService contactService;
    private String testKey;
  
    @BeforeEach																// Before each test.
    public void setup() {
        System.out.println("Instantiating Contact List");
        contactService = new ContactService();								// Create class Object
        testKey = contactService.addContact("John", "Smithy", "0123456789", "John's Address"); // Call addContact method with contact variables.
    }
    
    @Test
    @DisplayName("Contact Added")
	public void testAddContact() {
	    assertFalse(contactService.contactList.keySet().isEmpty());  		// Passes if the HashMap is not empty.
	    assertEquals(1, contactService.contactList.keySet().size());		// Passes if there is one contact in HashMap.
	    assertTrue(contactService.contactList.containsKey(testKey) && contactService.contactList.get(testKey) != null); // Passes if ContactList contains key and taskList value is not null.
	    assertEquals("John", contactService.getContactFirstName(testKey));	// Passes if first name is assigned.
	    assertEquals("Smithy", contactService.getContactLastName(testKey));	// Passes if last name is assigned.
	    assertEquals("0123456789", contactService.getContactPhoneNumber(testKey));	// Passes if phone number is assigned.
	    assertEquals("John's Address", contactService.getContactAddress(testKey));	// Passes if address is assigned.
    }    
    @Test
    @DisplayName("Update Last Contact First Name")
    public void testUpdateFirstName() {
		contactService.updateFirstName(testKey, "Jane");					// Updates the value from John to Jane.
		assertEquals("Jane", contactService.getContactFirstName(testKey));	// Passes test if the firstName returned is from contact is Jane.
		assertThrows(IllegalArgumentException.class, () -> {				// Passes if the taskList does not contain the key, "Not a key"
    		contactService.updateFirstName("Not a Key", "FirstName");		// Passes if contactKey is incorrect.
        });
    }
    @Test
    @DisplayName("Update Last Contact Last Name")
    public void testUpdateLastName() {
		contactService.updateLastName(testKey, "Doe");
		assertEquals("Doe", contactService.getContactLastName(testKey));
		assertThrows(IllegalArgumentException.class, () -> {				// Passes if the taskList does not contain the key, "Not a key"
    		contactService.updateLastName("Not a Key", "LastName");			// Passes if contactKey is incorrect.
        });
    }
    @Test
    @DisplayName("Update Last Contact Phone Number Name")
    public void testUpdatePhoneNumber() {
		contactService.updatePhoneNumber(testKey, "9876543210");
		assertEquals("9876543210", contactService.getContactPhoneNumber(testKey));
		assertThrows(IllegalArgumentException.class, () -> {				// Passes if the taskList does not contain the key, "Not a key"
    		contactService.updatePhoneNumber("Not a Key", "0123456789");	// Passes if contactKey is incorrect.
        });
    }
    @Test
    @DisplayName("Update Last Contact Address Name")
    public void testUpdateAddress() {
		contactService.updateAddress(testKey, "New Address");
		assertEquals("New Address", contactService.getContactAddress(testKey));
		assertThrows(IllegalArgumentException.class, () -> {				// Passes if the taskList does not contain the key, "Not a key"
    		contactService.updateAddress("Not a Key", "New Address");		// Passes if contactKey is incorrect.
        });
    }
    @Test
    @DisplayName("Delete Last Contact")
    public void testDeleteContact() {
    	assertThrows(IllegalArgumentException.class, () -> {				// Passes if the taskList does not contain the key, "Not a key"
    		contactService.deleteContact("Not a Key");						// Passes if contactKey is incorrect.
        });
    	contactService.deleteContact(testKey);   							// Deletes the before each contact service key value pair.
    	assertTrue(contactService.contactList.keySet().isEmpty());		 	// Tests that it is empty. 
    }   
}