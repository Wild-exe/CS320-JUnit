package contactManager;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertThrows;
import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

public class ContactTest {
    private Contact contact;
    
    @BeforeEach
    public void setup() {
        System.out.println("Instantiating Contact");
        contact = new Contact("ValidID", "John", "Smith", "0123456789", "John's Address");	//Creates the class object for each test.
    }
    
	@Test
	@DisplayName("Testing Contact")
	public void testContact() {
		assertEquals("ValidID", contact.getContactID());						// Passes if the variables was assigned properly
		assertEquals("John", contact.getFirstName());
		assertEquals("Smith", contact.getLastName());
		assertEquals("0123456789", contact.getPhoneNumber());
		assertEquals("John's Address", contact.getAddress());
	}	
    @Test
    @DisplayName("Validating ContactID for null and length.")
	public void testValidateID() {
    	assertThrows(IllegalArgumentException.class, () -> {  					// Test passes if exception is thrown.
            contact.setContactID(null);							 				// Testing validate method for null.
        });
    	assertThrows(IllegalArgumentException.class, () -> {
            contact.setContactID("A".repeat(11));								// Testing validate method for string with a length of 11.
        });
    	assertDoesNotThrow(() -> {								
    		contact.setContactID("Valid");										// Passes if an exception isn't thrown.
    	});    	
    }
    @Test
    @DisplayName("Validating First Name for null and length.")
	public void testValidateFirstName() {
    	assertThrows(IllegalArgumentException.class, () -> {
            contact.setFirstName(null);
        });
    	assertThrows(IllegalArgumentException.class, () -> {
            contact.setFirstName("A".repeat(11));
    	});
    	assertDoesNotThrow(() -> {								
    		contact.setFirstName("Valid");
    	});
    }
    @Test
    @DisplayName("Validating Last Name for null and length.")
	public void testValidateLastName() {
    	assertThrows(IllegalArgumentException.class, () -> {
            contact.setLastName(null);
        });
    	assertThrows(IllegalArgumentException.class, () -> {
            contact.setLastName("A".repeat(11));
        });
    	assertDoesNotThrow(() -> {								
    		contact.setLastName("Valid");
    	});
    }
    @Test
    @DisplayName("Validating Phone Number for null, length and numeric.")
	public void testValidatePhoneNumber() {
    	assertThrows(IllegalArgumentException.class, () -> {
            contact.setPhoneNumber(null);
        });
    	assertThrows(IllegalArgumentException.class, () -> {
            contact.setPhoneNumber("A".repeat(11));
        });
    	assertThrows(IllegalArgumentException.class, () -> {		// Passes if the string is less than a length of 10.
            contact.setPhoneNumber("012345678");
        });
    	assertThrows(IllegalArgumentException.class, () -> {		// Tests for string with non numeric values.
            contact.setPhoneNumber("012345678.");
        });
    	assertThrows(IllegalArgumentException.class, () -> {		// Tests for white space.
            contact.setPhoneNumber("01234 5678");
        });
    	assertThrows(IllegalArgumentException.class, () -> {		// Tests for alphabetical.
            contact.setPhoneNumber("A012345678");
        });
    	assertDoesNotThrow(() -> {								
    		contact.setPhoneNumber("0123456789");
    	});
    }
    @Test
    @DisplayName("Validating ContactID for null and length.")
	public void testValidateAddress() {
    	assertThrows(IllegalArgumentException.class, () -> {
            contact.setAddress(null);
        });
    	assertThrows(IllegalArgumentException.class, () -> {
            contact.setAddress("A".repeat(31));
        });
    	assertDoesNotThrow(() -> {								
    		contact.setAddress("Valid");
    	});
    }
}
