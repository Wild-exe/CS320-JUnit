package contactManager;

public class Contact {
	private String contactID;								// Class variables
	private String firstName;
    private String lastName;
    private String phoneNumber;
    private String address;
    private static final byte ID_LENGTH = 10;				// Length requirements
	private static final byte FIRST_NAME_LENGTH = 10;
	private static final byte LAST_NAME_LENGTH = 10;
	private static final byte PHONE_NUM_LENGTH = 10;
	private static final byte ADDRESS_LENGTH = 30;

	public Contact(String contactID, String firstName, String lastName, String phoneNumber, String address) {	// Constructor
        this.contactID = setContactID(contactID);				// Calls validating set methods to assign parameter
        this.firstName = setFirstName(firstName);
        this.lastName = setLastName(lastName);
        this.phoneNumber = setPhoneNumber(phoneNumber);
        this.address = setAddress(address);
	}
    public String setContactID(String contactID) {				// Ensures the contact ID before assigning.
        if (contactID == null) {								// If there is not a value,
            throw new IllegalArgumentException("Contact ID cannot be empty.");	// throw exception
    	} else if (contactID.length() > ID_LENGTH) {		// If the length is greater than the allowed length,
    		throw new IllegalArgumentException("Contact ID cannot exceed " + ID_LENGTH + "characters.");  // throw exception.
    	} else {
    		return contactID;									// Else assign to to the contact
    	}
    }
    public String setFirstName(String firstName) {
        if (firstName == null) {
            throw new IllegalArgumentException("First name cannot be empty.");
    	} else if (firstName.length() > FIRST_NAME_LENGTH) {
    		throw new IllegalArgumentException("First name cannot exceed " + FIRST_NAME_LENGTH + "characters.");
    	} else {
    		return firstName;
    	}
    }
    public String setLastName(String lastName) {
    	 if (lastName == null) {
             throw new IllegalArgumentException("Last name cannot be empty.");
     	} else if (lastName.length() > LAST_NAME_LENGTH) {
     		throw new IllegalArgumentException("Last name cannot exceed " + LAST_NAME_LENGTH + "characters.");
     	} else {
     		return lastName;
     	}
    }
    public String setPhoneNumber(String phoneNumber) {
        if (phoneNumber == null) {
          throw new IllegalArgumentException("Phone number cannot be empty.");
        } else if (phoneNumber.length() != PHONE_NUM_LENGTH) {					// Phone number must be proper length(10).
          throw new IllegalArgumentException("Phone number length is incorrect. Input " + PHONE_NUM_LENGTH + " digits.");
        } else if (!phoneNumber.matches("\\d+")) {								// If phoneNumber is not numeric,
          throw new IllegalArgumentException( "Phone number can only contain numbers");	// throw exception.
        } else {
          return phoneNumber;
        }
    }
    public String setAddress(String address) {
        if (address == null) {
            throw new IllegalArgumentException("Address is empty.");
    	} else if (address.length() > ADDRESS_LENGTH) {
    		throw new IllegalArgumentException("Address cannot exceed " + ADDRESS_LENGTH + "characters.");
    	} else {
    		return address;
    	}
    }
    
	public void newFirstName(String firstName) {							// Update setter methods for testing updates in contact service.
		this.firstName = setFirstName(firstName);
	}	
	public void newLastName(String lastName) {
		this.lastName = setLastName(lastName);
	}
	public void newPhoneNumber(String phoneNumber) {
		this.phoneNumber = setPhoneNumber(phoneNumber);
	}	
	public void newAddress(String address) {
		this.address = setAddress(address);
	}
	
    public final String getContactID() { return contactID; }				// Getters for contact variables.
    public final String getFirstName() { return firstName; }
    public final String getLastName() { return lastName; }
    public final String getPhoneNumber() { return phoneNumber; }
    public final String getAddress() { return address; }
}